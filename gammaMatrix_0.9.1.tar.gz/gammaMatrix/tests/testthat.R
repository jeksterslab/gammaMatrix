library(testthat)
library(gammaMatrix)

test_check("gammaMatrix")
